/**
 * Hydration Risk Engine
 * 
 * Implements the exact custom physiological and environmental risk model specified:
 * Hydration Risk = (0.30 * Heart Load) + (0.25 * Activity Load) + (0.20 * Temperature Load) + (0.10 * Humidity Load) + (0.15 * Time Load)
 */

export interface HydrationEngineInput {
  heartRate: number;              // BPM
  activityLoad: number;           // 0-100 active movement index
  temperature: number;            // °C ambient
  humidity: number;               // % relative humidity
  timeSinceWaterIntake: number;   // Hours since last hydration log
}

export type HydrationRiskStatus = 'Hydrated' | 'Mild Risk' | 'High Risk' | 'Critical';

export interface HydrationEngineOutput {
  score: number;                  // 0-100 Risk Score
  status: HydrationRiskStatus;    // Risk Status Category
  meaning: string;                // Physiological explanation
  suggestedAction: string;        // Clinical hydration recommendation
  glassesRequired?: number;       // Suggested glasses needed to recover
  
  // Intermediate debug and analytics load values
  heartLoad: number;
  activityLoadScore: number;      // To distinguish from input key
  temperatureLoad: number;
  humidityLoad: number;
  timeLoad: number;
}

export class HydrationRiskEngine {
  /**
   * Calculates Heart Load (0-100) based on current heart rate.
   * Heart Rate < 80 bpm = 10
   * 80-100 bpm = 40
   * 100-120 bpm = 70
   * >120 bpm = 90
   */
  public static calculateHeartLoad(heartRate: number): number {
    if (heartRate < 80) return 10;
    if (heartRate <= 100) return 40;
    if (heartRate <= 120) return 70;
    return 90;
  }

  /**
   * Calculates Activity Load (0-100) based on motion sensor activity.
   * Sedentary = 10 (activityLoad < 20)
   * Walking = 40 (activityLoad 20-50)
   * Moderate Activity = 70 (activityLoad 50-80)
   * Workout / High Activity = 90 (activityLoad >= 80)
   */
  public static calculateActivityLoad(activityLoad: number): number {
    if (activityLoad < 20) return 10;
    if (activityLoad <= 50) return 40;
    if (activityLoad <= 80) return 70;
    return 90;
  }

  /**
   * Calculates Temperature Load (0-100) based on ambient temperature.
   * <22°C = 10
   * 22-28°C = 30
   * 28-32°C = 60
   * >32°C = 90
   */
  public static calculateTemperatureLoad(temperature: number): number {
    if (temperature < 22) return 10;
    if (temperature <= 28) return 30;
    if (temperature <= 32) return 60;
    return 90;
  }

  /**
   * Calculates Humidity Load (0-100) based on ambient humidity.
   * <40% = 20
   * 40-60% = 40
   * 60-75% = 70
   * >75% = 90
   */
  public static calculateHumidityLoad(humidity: number): number {
    if (humidity < 40) return 20;
    if (humidity <= 60) return 40;
    if (humidity <= 75) return 70;
    return 90;
  }

  /**
   * Calculates Time Load (0-100) based on time since last water intake.
   * <30 mins (<0.5 hrs) = 10
   * 30-60 mins (0.5 to 1.0 hrs) = 30
   * 1-2 hrs (1.0 to 2.0 hrs) = 60
   * >2 hrs (>2.0 hrs) = 90
   */
  public static calculateTimeLoad(hoursSinceDrink: number): number {
    const minutes = hoursSinceDrink * 60;
    if (minutes < 30) return 10;
    if (minutes <= 60) return 30;
    if (minutes <= 120) return 60;
    return 90;
  }

  /**
   * Computes the Hydration Risk Score using exact user weights:
   * Hydration Risk = (0.30 * Heart Load) + (0.25 * Activity Load) + (0.20 * Temperature Load) + (0.10 * Humidity Load) + (0.15 * Time Load)
   */
  public static solveRisk(
    inputs: HydrationEngineInput,
    activeAbsorbedHydration: number = 200 // Physiological buffer
  ): HydrationEngineOutput {
    const heartLoad = this.calculateHeartLoad(inputs.heartRate);
    const activityLoadScore = this.calculateActivityLoad(inputs.activityLoad);
    const temperatureLoad = this.calculateTemperatureLoad(inputs.temperature);
    const humidityLoad = this.calculateHumidityLoad(inputs.humidity);
    const timeLoad = this.calculateTimeLoad(inputs.timeSinceWaterIntake);

    // Dynamic formula computation
    const rawRisk = 
      (0.30 * heartLoad) + 
      (0.25 * activityLoadScore) + 
      (0.20 * temperatureLoad) + 
      (0.10 * humidityLoad) + 
      (0.15 * timeLoad);

    // Clamp risk score strictly between 0 and 100
    const finalRisk = Math.min(100, Math.max(0, Math.round(rawRisk)));

    // Status mapping:
    // 0-25 = Hydrated
    // 26-50 = Mild Risk
    // 51-75 = High Risk
    // 76-100 = Critical
    let status: HydrationRiskStatus;
    let meaning = '';
    let suggestedAction = '';
    let glassesRequired: number | undefined;

    if (finalRisk <= 25) {
      status = 'Hydrated';
      meaning = 'Body signals appear stable. Hydration levels are likely sufficient.';
      suggestedAction = 'Maintain current healthy beverage routing habits.';
    } else if (finalRisk <= 50) {
      status = 'Mild Risk';
      meaning = 'Early signs of dehydration risk detected based on activity, heart rate, environmental conditions, or prolonged hydration gap.';
      suggestedAction = 'Drink water soon.';
      glassesRequired = 1;
    } else if (finalRisk <= 75) {
      status = 'High Risk';
      meaning = 'Multiple physiological and environmental indicators suggest increasing dehydration probability.';
      suggestedAction = 'Hydrate immediately and reduce exertion if needed.';
      glassesRequired = 2;
    } else {
      status = 'Critical';
      meaning = 'High strain, prolonged hydration gap, elevated activity or heat load detected. Potential significant dehydration risk.';
      suggestedAction = 'Immediate hydration recommended. Rest and recover if symptoms persist.';
      glassesRequired = Math.min(5, Math.max(3, Math.round((finalRisk * 4) / 80)));
    }

    return {
      score: finalRisk,
      status,
      meaning,
      suggestedAction,
      glassesRequired,
      heartLoad,
      activityLoadScore,
      temperatureLoad,
      humidityLoad,
      timeLoad
    };
  }
}
