import { SensorData, HydrationRiskDetails } from '../types';
import { HydrationRiskEngine } from './hydrationRiskEngine';

/**
 * Calculates physiological physiological indicator score for heart rate.
 * Lower baseline (e.g. 60-70 bpm) -> lower stress score. High bpm -> higher sweat stress.
 */
export function calculateHeartScore(heartRate: number): number {
  return HydrationRiskEngine.calculateHeartLoad(heartRate);
}

/**
 * Calculates heat score based on ambient temperature and relative humidity.
 * Elevating temp and high humidity prevents convective/evaporative cooling, amplifying fluid loss.
 */
export function calculateHeatScore(temperature: number, humidity: number): number {
  return Math.round((HydrationRiskEngine.calculateTemperatureLoad(temperature) * 2 + HydrationRiskEngine.calculateHumidityLoad(humidity)) / 3);
}

/**
 * Calculates hydration risk score from distinct physiological and environmental inputs,
 * leveraging the unified HydrationRiskEngine core.
 * 
 * Returns full details for front-end styling and alert status.
 */
export function runHydrationRiskSolver(
  sensorData: Omit<SensorData, 'hydrationScore'>,
  hoursSinceDrink: number,
  activeAbsorbedHydration: number = 200
): HydrationRiskDetails {
  // Delegate mathematical solution directly to the newly implemented HydrationRiskEngine
  const engineOutput = HydrationRiskEngine.solveRisk({
    heartRate: sensorData.heartRate,
    activityLoad: sensorData.activityLoad,
    temperature: sensorData.temperature,
    humidity: sensorData.humidity,
    timeSinceWaterIntake: hoursSinceDrink
  }, activeAbsorbedHydration);

  // Map engine status directly to gorgeous premium design tokens
  let color = 'from-emerald-400 to-teal-500';
  let bgColor = 'bg-emerald-500/10';
  let textGlow = 'shadow-emerald-500/40 text-emerald-400';

  switch (engineOutput.status) {
    case 'Hydrated':
      color = 'from-emerald-400 to-teal-500';
      bgColor = 'bg-emerald-500/10';
      textGlow = 'shadow-emerald-500/40 text-emerald-400';
      break;
    case 'Mild Risk':
      color = 'from-yellow-400 to-amber-500';
      bgColor = 'bg-amber-500/10';
      textGlow = 'shadow-amber-500/40 text-amber-400';
      break;
    case 'High Risk':
      color = 'from-orange-500 to-rose-400';
      bgColor = 'bg-orange-500/10';
      textGlow = 'shadow-orange-500/40 text-orange-400';
      break;
    case 'Critical':
      color = 'from-red-600 to-rose-600';
      bgColor = 'bg-red-500/20';
      textGlow = 'shadow-red-600/50 text-red-500 font-bold animate-pulse';
      break;
  }

  return {
    score: engineOutput.score,
    status: engineOutput.status,
    color,
    bgColor,
    textGlow,
    meaning: engineOutput.meaning,
    suggestedAction: engineOutput.suggestedAction,
    glassesRequired: engineOutput.glassesRequired,
    // Intermediate Loads
    heartLoad: engineOutput.heartLoad,
    activityLoad: engineOutput.activityLoadScore,
    temperatureLoad: engineOutput.temperatureLoad,
    humidityLoad: engineOutput.humidityLoad,
    timeLoad: engineOutput.timeLoad
  };
}
